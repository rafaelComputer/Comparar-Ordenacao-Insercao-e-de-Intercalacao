"""Implementações de ordenação por inserção e por intercalação (merge sort)."""

def ordenacao_insercao(lista, contar=False):
    """Ordena uma cópia da lista. Retorna (lista_ordenada, comparações)."""
    a = list(lista)
    comparacoes = 0
    for i in range(1, len(a)):
        chave = a[i]
        j = i - 1
        # A comparação chave < a[j] é contada inclusive quando falha.
        while j >= 0:
            comparacoes += 1
            if chave < a[j]:
                a[j + 1] = a[j]
                j -= 1
            else:
                break
        a[j + 1] = chave
    return (a, comparacoes) if contar else a


def ordenacao_intercalacao(lista, contar=False):
    """Merge sort recursivo. Retorna (lista_ordenada, comparações) se contar=True."""
    a = list(lista)
    comparacoes = 0

    def ordenar(inicio, fim):
        nonlocal comparacoes
        if fim - inicio <= 1:
            return a[inicio:fim]
        meio = (inicio + fim) // 2
        esquerda = ordenar(inicio, meio)
        direita = ordenar(meio, fim)
        i = j = 0
        resultado = []
        while i < len(esquerda) and j < len(direita):
            comparacoes += 1
            if esquerda[i] <= direita[j]:
                resultado.append(esquerda[i])
                i += 1
            else:
                resultado.append(direita[j])
                j += 1
        resultado.extend(esquerda[i:])
        resultado.extend(direita[j:])
        return resultado

    ordenada = ordenar(0, len(a))
    return (ordenada, comparacoes) if contar else ordenada
