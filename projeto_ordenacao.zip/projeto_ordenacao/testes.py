"""Testes dos algoritmos, incluindo os casos difíceis solicitados."""
import unittest
from ordenacao import ordenacao_insercao, ordenacao_intercalacao

class TestOrdenacoes(unittest.TestCase):
    def setUp(self):
        self.algoritmos = (ordenacao_insercao, ordenacao_intercalacao)

    def test_casos_dificeis(self):
        casos = [
            [],
            [42],
            [7, 7, 7, 7, 7],
            [1, 2, 3, 4, 5, 6],
            [6, 5, 4, 3, 2, 1],
            [3, -1, 8, 0, -1, 5],
        ]
        for algoritmo in self.algoritmos:
            for caso in casos:
                with self.subTest(algoritmo=algoritmo.__name__, caso=caso):
                    resultado = algoritmo(caso)
                    self.assertEqual(resultado, sorted(caso))
                    self.assertEqual(caso, caso[:])  # a entrada não é alterada

    def test_contagem_disponivel(self):
        for algoritmo in self.algoritmos:
            resultado, comparacoes = algoritmo([3, 1, 2], contar=True)
            self.assertEqual(resultado, [1, 2, 3])
            self.assertIsInstance(comparacoes, int)
            self.assertGreaterEqual(comparacoes, 0)

    def test_entrada_nao_e_alterada(self):
        original = [4, 2, 3, 1]
        for algoritmo in self.algoritmos:
            algoritmo(original)
            self.assertEqual(original, [4, 2, 3, 1])

if __name__ == "__main__":
    unittest.main()
