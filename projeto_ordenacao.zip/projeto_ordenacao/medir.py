"""Executa benchmarks, grava CSVs e gera os dois gráficos do projeto."""
import csv
import random
import statistics
import time
from pathlib import Path
import matplotlib
matplotlib.use("Agg")  ## caso queira que os gráficos sejam exibidos na tela, remova "matplotlib.use("Agg")" e chame "plt.show()" no final de cada gráfico.
import matplotlib.pyplot as plt

from ordenacao import ordenacao_insercao, ordenacao_intercalacao

RAIZ = Path(__file__).resolve().parent
DIRETORIO_DADOS = RAIZ / "dados"
DIRETORIO_GRAFICOS = RAIZ / "graficos"
TAMANHOS = [5, 10, 20, 30, 50, 75, 100, 200, 500, 1000]
REPETICOES = 10
SEMENTE = 20261015

class ValorContador:
    """Envolve um inteiro e conta chamadas de comparação < feitas pelo sorted()."""
    total = 0
    def __init__(self, valor):
        self.valor = valor
    def __lt__(self, outro):
        type(self).total += 1
        return self.valor < outro.valor

def medir_tempo(funcao, entrada):
    inicio = time.perf_counter()
    funcao(entrada)
    return time.perf_counter() - inicio

def medir_sorted_com_comparacoes(entrada):
    ValorContador.total = 0
    envolvidos = [ValorContador(x) for x in entrada]
    inicio = time.perf_counter()
    sorted(envolvidos)
    tempo = time.perf_counter() - inicio
    return tempo, ValorContador.total

def main():
    DIRETORIO_DADOS.mkdir(exist_ok=True)
    DIRETORIO_GRAFICOS.mkdir(exist_ok=True)
    rng = random.Random(SEMENTE)
    linhas = []

    for n in TAMANHOS:
        tempos_ins, tempos_int, tempos_sorted = [], [], []
        comps_ins, comps_int, comps_sorted = [], [], []
        for _ in range(REPETICOES):
            entrada = [rng.randrange(0, max(10, n * 10)) for _ in range(n)]

            # Medições de tempo usam as implementações normais; contagem em separado.
            tempos_ins.append(medir_tempo(ordenacao_insercao, entrada))
            tempos_int.append(medir_tempo(ordenacao_intercalacao, entrada))
            ts, cs = medir_sorted_com_comparacoes(entrada)
            tempos_sorted.append(ts)

            _, ci = ordenacao_insercao(entrada, contar=True)
            _, cm = ordenacao_intercalacao(entrada, contar=True)
            comps_ins.append(ci)
            comps_int.append(cm)
            comps_sorted.append(cs)

        linhas.append({
            "n": n,
            "tempo_insercao_s": statistics.mean(tempos_ins),
            "tempo_intercalacao_s": statistics.mean(tempos_int),
            "tempo_sorted_s": statistics.mean(tempos_sorted),
            "comparacoes_insercao": statistics.mean(comps_ins),
            "comparacoes_intercalacao": statistics.mean(comps_int),
            "comparacoes_sorted": statistics.mean(comps_sorted),
            "repeticoes": REPETICOES,
            "semente": SEMENTE,
        })

    csv_path = DIRETORIO_DADOS / "dados.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        escritor = csv.DictWriter(f, fieldnames=list(linhas[0].keys()))
        escritor.writeheader()
        escritor.writerows(linhas)

    # Gráfico de tempos
    plt.figure(figsize=(9, 5.5))
    plt.plot([x["n"] for x in linhas], [x["tempo_insercao_s"] * 1000 for x in linhas], marker="o", label="Inserção")
    plt.plot([x["n"] for x in linhas], [x["tempo_intercalacao_s"] * 1000 for x in linhas], marker="o", label="Intercalação (merge sort)")
    plt.plot([x["n"] for x in linhas], [x["tempo_sorted_s"] * 1000 for x in linhas], marker="o", label="sorted() do Python")
    plt.xlabel("Tamanho da lista (n)")
    plt.ylabel("Tempo médio (ms)")
    plt.title("Tempo médio de ordenação — 10 repetições por tamanho")
    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.savefig(DIRETORIO_GRAFICOS / "tempos.png", dpi=160)
    plt.close()

    # Gráfico de comparações
    plt.figure(figsize=(9, 5.5))
    plt.plot([x["n"] for x in linhas], [x["comparacoes_insercao"] for x in linhas], marker="o", label="Inserção")
    plt.plot([x["n"] for x in linhas], [x["comparacoes_intercalacao"] for x in linhas], marker="o", label="Intercalação (merge sort)")
    plt.plot([x["n"] for x in linhas], [x["comparacoes_sorted"] for x in linhas], marker="o", label="sorted() do Python")
    plt.xlabel("Tamanho da lista (n)")
    plt.ylabel("Número médio de comparações")
    plt.title("Comparações médias — 10 repetições por tamanho")
    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.savefig(DIRETORIO_GRAFICOS / "comparacoes.png", dpi=160)
    plt.close()

    print(f"CSV: {csv_path}")
    print(f"Gráficos: {DIRETORIO_GRAFICOS}")
    for linha in linhas:
        print(linha)

if __name__ == "__main__":
    main()
