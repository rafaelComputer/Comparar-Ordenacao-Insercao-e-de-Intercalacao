# Relatório — Ordenação por inserção e por intercalação

## Objetivo
Comparar a ordenação por inserção, a ordenação por intercalação (merge sort) e a função `sorted()` do Python usando listas aleatórias. Foram medidos tempo de execução e número de comparações.

## Metodologia
- Tamanhos: 5, 10, 20, 30, 50, 75, 100, 200, 500 e 1000.
- 10 repetições para cada tamanho; os tempos apresentados são médias.
- Listas pseudoaleatórias geradas com semente fixa (`20261015`) para facilitar a reprodução.
- Tempo medido com `time.perf_counter()`. Os tempos são muito pequenos nos menores tamanhos, então podem variar conforme computador, carga do sistema e versão do Python.
- As comparações dos algoritmos próprios são contadas no momento em que um elemento é comparado com outro. Para `sorted()`, uma classe auxiliar conta chamadas de `__lt__`.
- O custo de criar os objetos auxiliares para contar `sorted()` não está incluído no tempo de `sorted()`? **Está incluído**: a lista de objetos é criada antes do cronômetro, e somente a chamada `sorted()` é cronometrada.

## Tabela de tempos médios

Valores em milissegundos (ms).

| n | Inserção (ms) | Intercalação (ms) | `sorted()` (ms) |
|---:|---:|---:|---:|
| 5 | 0.0013 | 0.0059 | 0.0040 |
| 10 | 0.0022 | 0.0056 | 0.0084 |
| 20 | 0.0075 | 0.0121 | 0.0183 |
| 30 | 0.0170 | 0.0196 | 0.0205 |
| 50 | 0.0467 | 0.0374 | 0.0370 |
| 75 | 0.1079 | 0.0622 | 0.0796 |
| 100 | 0.2168 | 0.1007 | 0.0961 |
| 200 | 0.7831 | 0.2077 | 0.2601 |
| 500 | 5.2300 | 0.6241 | 0.7261 |
| 1000 | 25.2236 | 1.5585 | 1.7335 |

## Tabela de comparações médias

Valores médios; podem aparecer casas decimais porque são médias de 10 execuções.

| n | Inserção | Intercalação | `sorted()`* |
|---:|---:|---:|---:|
| 5 | 7,5 | 7,0 | 9,0 |
| 10 | 26,8 | 22,8 | 24,4 |
| 20 | 109,0 | 62,9 | 64,3 |
| 30 | 252,1 | 111,3 | 111,4 |
| 50 | 643,9 | 220,1 | 218,5 |
| 75 | 1.499,2 | 374,7 | 372,9 |
| 100 | 2.508,4 | 544,0 | 537,7 |
| 200 | 10.162,0 | 1.282,2 | 1.274,0 |
| 500 | 62.787,5 | 3.855,9 | 3.831,5 |
| 1000 | 251.475,2 | 8.712,8 | 8.653,2 |

\* Para `sorted()`, a contagem é o número de chamadas a `__lt__`, não o total de todas as operações internas do algoritmo.

## Gráficos

- [Gráfico de tempos](graficos/tempos.png)
- [Gráfico de comparações](graficos/comparacoes.png)

Os arquivos PNG estão na pasta `graficos/` e são regenerados por `python medir.py`.

## Em que n a intercalação passa a ser mais rápida?
Neste experimento, a intercalação passa a ter menor tempo médio que a inserção em **n = 50**. Para n = 30, a inserção ainda foi ligeiramente mais rápida; para n = 50, a intercalação já foi mais rápida. Esse ponto de virada é experimental, não uma constante universal: depende do computador, da implementação e dos dados.

## O gráfico de comparações e o de tempo dão o mesmo ponto de virada?
**Não.** Em comparações, a intercalação já apresenta menos comparações em n = 5 (7,0 contra 7,5, em média) e continua usando menos nos tamanhos maiores. Em tempo, porém, a inserção é mais rápida nos tamanhos pequenos, até n = 30, e a intercalação só a supera em n = 50. Isso acontece porque tempo não depende apenas do número de comparações: a intercalação tem custo extra de recursão, criação e combinação de listas, enquanto a inserção tem um fluxo de execução mais simples e baixo custo fixo. Em listas pequenas, esse custo fixo pesa bastante.

## Por que `sorted()` não serve para decidir entre os dois algoritmos?
`sorted()` é uma referência útil de desempenho prático, mas não é uma comparação direta entre os dois algoritmos implementados aqui. A função usa o Timsort, um algoritmo híbrido altamente otimizado na implementação do Python, e não a nossa implementação de inserção ou merge sort. Além disso, o código de `sorted()` é executado em grande parte em código nativo otimizado, enquanto as implementações deste projeto são Python puro. Portanto, comparar o tempo de `sorted()` com os tempos próprios mostra a vantagem prática da biblioteca, mas não isola qual dos dois algoritmos estudados é melhor. Para isso, compare inserção e intercalação implementadas sob condições semelhantes.

## Um caso em que a inserção ainda seria adequada
A ordenação por inserção é uma boa escolha para **listas pequenas** ou **quase ordenadas**. Ela é simples, usa memória extra constante e, quando os elementos já estão quase na posição correta, realiza poucas movimentações e comparações. Para listas grandes e aleatórias, seu crescimento quadrático tende a torná-la bem mais lenta.

## Análise final
A inserção tem comportamento quadrático no caso médio e no pior caso, aproximadamente O(n²). A intercalação tem crescimento O(n log n), com custo adicional de memória para combinar as partes. Os resultados medidos refletem isso: em n = 1000, a inserção levou aproximadamente 25.2236 ms, enquanto a intercalação levou 1.5585 ms. A diferença cresce bastante com o tamanho da lista.

A medição não prova que um algoritmo será sempre mais rápido a partir de um tamanho exato; ela mostra o ponto de virada nesta execução e neste ambiente. Para um relatório formal, é importante mencionar essa limitação.
