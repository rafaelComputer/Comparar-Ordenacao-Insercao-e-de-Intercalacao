# Comparação de algoritmos de ordenação

Projeto acadêmico que compara ordenação por inserção, ordenação por intercalação (merge sort) e `sorted()` do Python.

## Requisitos
- Python 3.9 ou superior
- `matplotlib` para gerar os gráficos (`python -m pip install matplotlib`)

## Como executar
Na pasta do projeto:

```bash
python -m unittest -v testes.py
python medir.py
```

O comando `python medir.py` refaz `dados/dados.csv` e os gráficos `graficos/tempos.png` e `graficos/comparacoes.png` do zero. São usados os tamanhos pedidos, 10 repetições por tamanho e semente fixa para reproduzir as listas aleatórias.

## Arquivos
- `ordenacao.py`: os dois algoritmos implementados.
- `testes.py`: testes, incluindo lista vazia, um elemento, valores iguais, ordenada e invertida.
- `medir.py`: medições, CSV e gráficos; inclui a contagem de comparações de `sorted()`.
- `dados/dados.csv`: dados brutos agregados pela média de 10 repetições.
- `graficos/`: gráficos gerados.
- `RELATORIO.md`: análise dos resultados.
